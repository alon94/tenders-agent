"use client";
import { useState, useEffect, useMemo } from "react";
import AppShell from "../components/AppShell";

interface Tender { id:string; title?:string; publisher?:string; publishDate?:string; deadline?:string; status?:string; url?:string; }

const DARK="#1a2330",BLUE="#2b6fc4",MUTED="#667380",BORDER="#e6eaee";
function fd(d?:string){if(!d)return'—';try{return new Date(d).toLocaleDateString('he-IL',{day:'2-digit',month:'2-digit',year:'numeric'});}catch{return d;}}

export default function AgentPage(){
  const [items,setItems]=useState<Tender[]>([]);
  const [loading,setLoading]=useState(true);
  const [date,setDate]=useState<string>("");
  useEffect(()=>{
    Promise.all([0,1000,2000,3000].map(o=>fetch("/api/tenders?offset="+o).then(r=>r.json()).catch(()=>({tenders:[]}))))
      .then(rs=>{const all:Tender[]=[];for(const r of rs)for(const t of(r.tenders||[]))all.push(t);setItems(all);
        const dates=all.map(t=>(t.publishDate||"").slice(0,10)).filter(Boolean).sort();if(dates.length)setDate(dates[dates.length-1]);setLoading(false);})
      .catch(()=>setLoading(false));
  },[]);
  const dateOptions=useMemo(()=>{const set=new Set<string>();items.forEach(t=>{const d=(t.publishDate||"").slice(0,10);if(d)set.add(d);});return Array.from(set).sort().reverse();},[items]);
  const dayItems=useMemo(()=>items.filter(t=>(t.publishDate||"").slice(0,10)===date),[items,date]);

  return(
    <AppShell active="/agent" title="סוכן חכם">
      {/* hero */}
      <div style={{background:DARK,borderRadius:12,padding:'24px 26px',color:'#fff',marginBottom:20,display:'flex',alignItems:'center',gap:20,flexWrap:'wrap'}}>
        <div style={{flex:1,minWidth:240}}>
          <div style={{fontSize:20,fontWeight:700,display:'flex',alignItems:'center',gap:10}}>◈ הסוכן החכם</div>
          <div style={{fontSize:13.5,opacity:.85,marginTop:6,lineHeight:1.5}}>הסוכן סורק את כל המקורות מדי יום ומציג את המכרזים שפורסמו בתאריך שבחרתם.</div>
        </div>
        <div style={{position:'relative'}}>
          <select value={date} onChange={e=>setDate(e.target.value)} style={{padding:'10px 34px 10px 14px',borderRadius:8,border:'none',background:'#fff',color:DARK,fontSize:14,fontWeight:600,appearance:'none',WebkitAppearance:'none',fontFamily:'inherit',cursor:'pointer'}}>
            {dateOptions.map(d=>(<option key={d} value={d}>{d}</option>))}
          </select>
          <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)',fontSize:10,color:'#9aa6b2',pointerEvents:'none'}}>▾</span>
        </div>
      </div>

      {loading?(
        <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,padding:50,textAlign:'center',color:MUTED,fontSize:14}}>הסוכן סורק מכרזים…</div>
      ):(
        <>
          <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:14}}>
            <span style={{background:DARK,color:'#fff',fontWeight:600,fontSize:13,padding:'8px 15px',borderRadius:7}}>נמצאו {dayItems.length} מכרזים</span>
            <span style={{fontSize:13,color:MUTED}}>לתאריך {date}</span>
          </div>
          {dayItems.length===0?(
            <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,padding:50,textAlign:'center',color:MUTED,fontSize:14}}>הסוכן לא מצא מכרזים לתאריך זה.</div>
          ):(
            <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
              <div style={{display:'grid',gridTemplateColumns:'1fr 200px 156px',padding:'12px 18px',background:'#f7f9fb',borderBottom:`1px solid ${BORDER}`,fontSize:12,fontWeight:700,color:'#8a97a3'}}>
                <span>נושא המכרז</span><span>גוף מפרסם</span><span>מועד הגשה</span>
              </div>
              {dayItems.map(t=>(
                <div key={t.id} style={{display:'grid',gridTemplateColumns:'1fr 200px 156px',padding:'16px 18px',borderBottom:'1px solid #eef1f4',alignItems:'center'}}>
                  <a href={`/tender/${t.id}`} style={{fontSize:15,fontWeight:600,color:DARK,textDecoration:'none',paddingInlineEnd:16,lineHeight:1.4}}>{t.title||'ללא כותרת'}</a>
                  <span style={{fontSize:13,color:'#5b6b7a'}}>{t.publisher||'לא ידוע'}</span>
                  <span style={{fontSize:13,color:DARK,fontWeight:600}}>{fd(t.deadline)}</span>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </AppShell>
  );
}
