"use client";
import { ReactNode } from "react";

/* ============ \u05de\u05e2\u05d8\u05e4\u05ea \u05d0\u05e0\u05d8\u05e8\u05e4\u05e8\u05d9\u05d9\u05d6 (\u05e2\u05d9\u05e6\u05d5\u05d1 2a) \u2014 \u05e1\u05e8\u05d2\u05dc \u05e6\u05d3 + header \u05de\u05e9\u05d5\u05ea\u05e3 ============ */

const DARK = "#1a2330", BLUE = "#2b6fc4", MUTED = "#667380", BORDER = "#e6eaee";

const NAV = [
  { icon: "\u25e7", label: "\u05d2\u05d9\u05dc\u05d5\u05d9 \u05de\u05db\u05e8\u05d6\u05d9\u05dd", href: "/dashboard" },
  { icon: "\u2605", label: "\u05de\u05db\u05e8\u05d6\u05d9\u05dd \u05de\u05e1\u05d5\u05de\u05e0\u05d9\u05dd", href: "/marked" },
  { icon: "\u25c8", label: "\u05e1\u05d5\u05db\u05df \u05d7\u05db\u05dd", href: "/agent" },
  { icon: "\u25a4", label: "\u05e2\u05e8\u05d1\u05d5\u05d9\u05d5\u05ea \u05d5\u05dc\u05d9\u05d5\u05d5\u05d9", href: "/guarantee" },
  { icon: "\u26c1", label: "\u05de\u05e7\u05d5\u05e8\u05d5\u05ea", href: "/sources" },
  { icon: "\u2699", label: "\u05e4\u05e8\u05d5\u05e4\u05d9\u05dc \u05e2\u05e1\u05e7\u05d9", href: "/profile" },
];

export default function AppShell({
  active, title, headerExtra, children,
}: { active: string; title: string; headerExtra?: ReactNode; children: ReactNode }) {
  return (
    <div style={{ minHeight: "100vh", background: "#f6f8fa", fontFamily: "'Assistant','Rubik',Arial,sans-serif", direction: "rtl", color: DARK }}>
      <div style={{ display: "flex", minHeight: "100vh" }}>

        {/* SIDEBAR */}
        <div style={{ flex: "0 0 238px", background: "#fff", borderInlineEnd: `1px solid ${BORDER}`, padding: "22px 16px", display: "flex", flexDirection: "column", gap: 3, position: "sticky", top: 0, alignSelf: "flex-start", height: "100vh" }}>
          <a href="/dashboard" style={{ display: "flex", alignItems: "center", gap: 11, padding: "0 8px 20px", marginBottom: 8, borderBottom: "1px solid #eef1f4", textDecoration: "none" }}>
            <div style={{ width: 34, height: 34, borderRadius: 8, background: BLUE, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 16, fontWeight: 800 }}>\u05e9</div>
            <div style={{ lineHeight: 1.15 }}><div style={{ fontWeight: 700, fontSize: 15.5, color: DARK }}>\u05e9\u05d5\u05d5\u05d4 \u05de\u05db\u05e8\u05d6\u05d9\u05dd</div><div style={{ fontSize: 11, color: "#8a97a3" }}>\u05de\u05d5\u05e2\u05d3\u05d5\u05df \u05e2\u05e1\u05e7\u05d9\u05dd 360</div></div>
          </a>
          {NAV.map((s) => {
            const on = s.href === active;
            return (
              <a key={s.label} href={s.href} style={{ display: "flex", alignItems: "center", gap: 11, padding: "11px 12px", borderRadius: 9, fontSize: 14.5, textDecoration: "none", fontWeight: on ? 700 : 500, background: on ? "#e8f1fb" : "transparent", color: on ? "#1e5aa8" : "#5b6b7a", borderInlineStart: on ? `3px solid ${BLUE}` : "3px solid transparent" }}>
                <span style={{ fontSize: 16, opacity: on ? 1 : .65 }}>{s.icon}</span>{s.label}
              </a>
            );
          })}
          <div style={{ marginTop: "auto", border: `1px solid ${BORDER}`, borderRadius: 12, padding: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 14, color: DARK }}>\u25c8 \u05d4\u05e1\u05d5\u05db\u05df \u05d4\u05d7\u05db\u05dd</div>
            <div style={{ fontSize: 12, color: MUTED, margin: "7px 0 12px", lineHeight: 1.5 }}>\u05e7\u05d1\u05dc\u05d5 \u05de\u05db\u05e8\u05d6\u05d9\u05dd \u05de\u05d5\u05ea\u05d0\u05de\u05d9\u05dd \u05dc\u05e4\u05d9 \u05d4\u05e4\u05e8\u05d5\u05e4\u05d9\u05dc \u05d4\u05e2\u05e1\u05e7\u05d9 \u05e9\u05dc\u05db\u05dd</div>
            <a href="/agent" style={{ display: "block", background: DARK, color: "#fff", fontWeight: 600, fontSize: 13, textAlign: "center", padding: 9, borderRadius: 8, textDecoration: "none" }}>\u05d4\u05e4\u05e2\u05dc\u05d4</a>
          </div>
        </div>

        {/* CONTENT */}
        <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
          <div style={{ background: "#fff", borderBottom: `1px solid ${BORDER}`, padding: "15px 26px", display: "flex", alignItems: "center", gap: 18, position: "sticky", top: 0, zIndex: 5 }}>
            <div style={{ fontWeight: 700, fontSize: 20, color: DARK, flex: "0 0 auto" }}>{title}</div>
            {headerExtra}
            <a href="/agent" style={{ marginInlineStart: headerExtra ? undefined : "auto", background: BLUE, color: "#fff", fontWeight: 600, fontSize: 13, padding: "9px 16px", borderRadius: 8, textDecoration: "none", flex: "0 0 auto" }}>\u2726 \u05ea\u05d5\u05d1\u05e0\u05d5\u05ea AI</a>
            <a href="/profile" style={{ width: 32, height: 32, borderRadius: 8, background: "#eef1f4", color: DARK, display: "inline-flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 13, textDecoration: "none", flex: "0 0 auto" }}>\u05d0</a>
          </div>
          <div style={{ padding: "22px 26px 40px", maxWidth: 1100, width: "100%" }}>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
