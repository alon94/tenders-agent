"use client";
import { useState, useEffect } from "react";
import AppShell from "../components/AppShell";

interface Tender { id:string; title?:string; publisher?:string; publishDate?:string; deadline?:string; status?:string; url?:string; }

const DARK="#1a2330",BLUE="#2b6fc4",MUTED="#667380",BORDER="#e6eaee";
function fd(d?:string){if(!d)return'—';try{return new Date(d).toLocaleDateString('he-IL',{day:'2-digit',month:'2-digit',year:'numeric'});}catch{return d;}}

export default function MarkedPage(){
  const [items,setItems]=useState<Tender[]>([]);
  const [loading,setLoading]=useState(true);
  const [marked,setMarked]=useState<string[]>([]);
  useEffect(()=>{
    let ids:string[]=[];
    try{const m=JSON.parse(localStorage.getItem("markedTenders")||"[]");if(Array.isArray(m))ids=m;}catch(e){}
    setMarked(ids);
    if(ids.length===0){setLoading(false);return;}
    Promise.all([0,1000,2000,3000].map(o=>fetch("/api/tenders?offset="+o).then(r=>r.json()).catch(()=>({tenders:[]}))))
      .then(rs=>{const all:Tender[]=[];for(const r of rs)for(const t of(r.tenders||[]))all.push(t);setItems(all.filter(t=>ids.includes(String(t.id))));setLoading(false);})
      .catch(()=>setLoading(false));
  },[]);
  function unmark(id:string){const next=marked.filter(x=>x!==id);setMarked(next);try{localStorage.setItem("markedTenders",JSON.stringify(next));}catch(e){}setItems(prev=>prev.filter(t=>String(t.id)!==id));}

  return(
    <AppShell active="/marked" title="מכרזים מסומנים">
      <div style={{fontSize:13,color:MUTED,marginBottom:18}}>המכרזים ששמרת לעיון מאוחר יותר{!loading&&` · ${items.length}`}</div>
      {loading?(
        <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,padding:50,textAlign:'center',color:MUTED,fontSize:14}}>טוען…</div>
      ):items.length===0?(
        <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,padding:50,textAlign:'center',color:MUTED,fontSize:14}}>אין מכרזים מסומנים עדיין. סמנו מכרזים בדף הבית כדי לראותם כאן.</div>
      ):(
        <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 200px 156px 60px',padding:'12px 18px',background:'#f7f9fb',borderBottom:`1px solid ${BORDER}`,fontSize:12,fontWeight:700,color:'#8a97a3'}}>
            <span>נושא המכרז</span><span>גוף מפרסם</span><span>מועד הגשה</span><span></span>
          </div>
          {items.map(t=>(
            <div key={t.id} style={{display:'grid',gridTemplateColumns:'1fr 200px 156px 60px',padding:'16px 18px',borderBottom:'1px solid #eef1f4',alignItems:'center'}}>
              <a href={`/tender/${t.id}`} style={{fontSize:15,fontWeight:600,color:DARK,textDecoration:'none',paddingInlineEnd:16,lineHeight:1.4}}>{t.title||'ללא כותרת'}</a>
              <span style={{fontSize:13,color:'#5b6b7a'}}>{t.publisher||'לא ידוע'}</span>
              <span style={{fontSize:13,color:DARK,fontWeight:600}}>{fd(t.deadline)}</span>
              <button onClick={()=>unmark(String(t.id))} title="הסר מסימונים" style={{fontSize:16,color:'#d9a520',background:'transparent',border:'none',cursor:'pointer',justifySelf:'end'}}>★</button>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
