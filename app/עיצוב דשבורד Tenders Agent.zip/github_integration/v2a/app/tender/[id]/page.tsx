'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import AppShell from '../../components/AppShell';

const DARK="#1a2330",BLUE="#2b6fc4",MUTED="#667380",BORDER="#e6eaee";

interface TenderDetail {
  id: string; title?: string; publisher?: string; publicationNumber?: string; status?: string;
  procedureNumber?: string; publishDate?: string; updateDate?: string; submissionStart?: string;
  deadline?: string; contactName?: string; contactEmail?: string; topics?: string[];
  documents?: { date?: string; title: string; description?: string; url: string }[];
  submissionUrl?: string; url?: string;
}

export default function TenderPage() {
  const params = useParams();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  const [tender, setTender] = useState<TenderDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    fetch(`/api/tender/${id}`)
      .then((r) => { if (!r.ok) throw new Error('failed'); return r.json(); })
      .then((data) => { setTender(data); setLoading(false); })
      .catch(() => { setError('לא ניתן לטעון את פרטי המכרז'); setLoading(false); });
  }, [id]);

  const box = (c: React.ReactNode) => <div style={{ background: '#fff', border: `1px solid ${BORDER}`, borderRadius: 10, padding: 40, textAlign: 'center', color: MUTED, fontSize: 14 }}>{c}</div>;

  return (
    <AppShell active="/dashboard" title="פרטי מכרז">
      <a href="/dashboard" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: BLUE, textDecoration: 'none', fontSize: 13.5, fontWeight: 600, marginBottom: 16 }}>← חזרה לרשימת המכרזים</a>

      {loading ? box('טוען פרטי מכרז…') : (error || !tender) ? box(<span style={{ color: '#b04a34' }}>{error || 'מכרז לא נמצא'}</span>) : (
        <div style={{ background: '#fff', border: `1px solid ${BORDER}`, borderRadius: 10, padding: '26px 28px' }}>
          <div style={{ marginBottom: 20, paddingBottom: 20, borderBottom: '1px solid #eef1f4' }}>
            {tender.status && <span style={{ display: 'inline-block', fontSize: 11.5, fontWeight: 600, padding: '3px 10px', borderRadius: 6, background: '#fbf3d8', color: '#96731a', border: '1px solid #f0e3b0', marginBottom: 12 }}>{tender.status}</span>}
            <h1 style={{ fontSize: 24, fontWeight: 700, color: DARK, lineHeight: 1.35, margin: '0 0 8px' }}>{tender.title || 'מכרז'}</h1>
            {tender.publisher && <p style={{ margin: 0, fontSize: 14.5, color: BLUE, fontWeight: 600 }}>{tender.publisher}</p>}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: '0 32px' }}>
            {[['מס׳ פרסום',tender.publicationNumber],['מס׳ הליך',tender.procedureNumber],['תאריך פרסום',tender.publishDate],['תאריך עדכון',tender.updateDate],['מועד תחילת ההגשה',tender.submissionStart],['מועד אחרון להגשה',tender.deadline],['פנייה למפרסם',tender.contactName],['דוא״ל',tender.contactEmail]].filter(([,v])=>v).map(([l,v],i)=>(
              <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 4, padding: '12px 0', borderBottom: '1px solid #f2f4f6' }}>
                <span style={{ fontSize: 12, color: MUTED, fontWeight: 600 }}>{l}</span>
                <span style={{ fontSize: 14.5, color: DARK, fontWeight: 600 }}>{v}</span>
              </div>
            ))}
          </div>

          {tender.topics && tender.topics.length > 0 && (
            <div style={{ marginTop: 24 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, color: DARK, marginBottom: 12 }}>נושאים</h2>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {tender.topics.map((t, i) => (<span key={i} style={{ fontSize: 12, fontWeight: 600, padding: '4px 11px', borderRadius: 6, background: '#eaf1fb', color: '#1e5aa8', border: '1px solid #d3e2f5' }}>{t}</span>))}
              </div>
            </div>
          )}

          {tender.documents && tender.documents.length > 0 && (
            <div style={{ marginTop: 24 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, color: DARK, marginBottom: 12 }}>מסמכים נלווים</h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: 12 }}>
                {tender.documents.map((d, i) => (
                  <a key={i} href={d.url} target="_blank" rel="noopener noreferrer" style={{ display: 'flex', flexDirection: 'column', gap: 6, padding: '14px 16px', borderRadius: 8, background: '#f7f9fb', border: `1px solid ${BORDER}`, textDecoration: 'none', color: DARK }}>
                    {d.date && <span style={{ fontSize: 11.5, color: MUTED }}>{d.date}</span>}
                    <span style={{ fontSize: 14, fontWeight: 600, color: DARK }}>{d.title}</span>
                    {d.description && <span style={{ fontSize: 12.5, color: MUTED }}>{d.description}</span>}
                    <span style={{ color: BLUE, fontSize: 12.5, marginTop: 2 }}>הורדה ↓</span>
                  </a>
                ))}
              </div>
            </div>
          )}

          <div style={{ display: 'flex', gap: 12, marginTop: 26, flexWrap: 'wrap' }}>
            {tender.submissionUrl && <a href={tender.submissionUrl} target="_blank" rel="noopener noreferrer" style={{ background: DARK, color: '#fff', textDecoration: 'none', borderRadius: 8, padding: '12px 26px', fontSize: 14.5, fontWeight: 700 }}>להגשת הצעה</a>}
            {tender.url && <a href={tender.url} target="_blank" rel="noopener noreferrer" style={{ background: '#fff', color: '#5b6b7a', textDecoration: 'none', borderRadius: 8, padding: '12px 26px', fontSize: 14.5, fontWeight: 600, border: `1px solid ${BORDER}` }}>צפייה במקור ↗</a>}
          </div>
        </div>
      )}
    </AppShell>
  );
}
