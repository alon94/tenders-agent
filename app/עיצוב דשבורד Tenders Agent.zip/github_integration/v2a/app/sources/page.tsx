"use client";
import AppShell from "../components/AppShell";

const DARK="#1a2330",BLUE="#2b6fc4",MUTED="#667380",BORDER="#e6eaee";

export default function SourcesPage(){
  const sources=[
    {name:'מינהל הרכש הממשלתי',desc:'המקור הרשמי למכרזים ממשלתיים. ממנו נשאבים פרטי המכרז והמסמכים הנלווים.',url:'https://mr.gov.il'},
    {name:'מפתח התקציב (BudgetKey)',desc:'מאגר נתונים פתוח המאגד את נתוני המכרזים הממשלתיים בצורה מובנית.',url:'https://next.obudget.org'},
  ];
  return(
    <AppShell active="/sources" title="מקורות">
      <div style={{fontSize:13,color:MUTED,marginBottom:18}}>רשימת המקורות הרשמיים שמהם אנו סורקים ואוספים מכרזים</div>
      <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
        {sources.map((s,i)=>(
          <div key={i} style={{display:'flex',alignItems:'center',gap:20,padding:'20px 22px',borderBottom:i<sources.length-1?'1px solid #eef1f4':'none'}}>
            <div style={{flex:1,minWidth:0}}>
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <span style={{fontSize:16,fontWeight:700,color:DARK}}>{s.name}</span>
                <span style={{display:'inline-flex',alignItems:'center',gap:6,background:'#e7f6ec',color:'#1e7d45',border:'1px solid #c6ead2',borderRadius:6,padding:'3px 10px',fontSize:11.5,fontWeight:600}}><span style={{width:7,height:7,borderRadius:999,background:'#1e9e5a'}}></span>סריקה פעילה</span>
              </div>
              <div style={{color:'#5b6b7a',fontSize:13.5,lineHeight:1.6,marginTop:8}}>{s.desc}</div>
            </div>
            <a href={s.url} target="_blank" rel="noopener noreferrer" style={{flex:'0 0 auto',background:DARK,color:'#fff',textDecoration:'none',borderRadius:8,padding:'10px 20px',fontSize:13,fontWeight:600}}>מעבר למקור ↗</a>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
