'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

const DARK="#1a2330",BLUE="#2b6fc4",MUTED="#667380",BORDER="#e6eaee";

type FormData = { businessName:string; ownerName:string; email:string; phone:string; category:string; region:string; notification:string; };
const cats = ['טכנולוגיה','בנייה','בריאות','חינוך','ניקיון ותחזוקה','מזון','בטיחות','סביבה','אחר'];
const regs = ['כל הארץ','צפון','מרכז','דרום','ירושלים','חיפה'];

const field={width:'100%',border:`1px solid #e2e7ec`,background:'#fff',borderRadius:8,padding:'11px 14px',fontSize:15,color:'#33475b',boxSizing:'border-box' as const,fontFamily:'inherit',outline:'none'};
const selField={...field,appearance:'none' as const,WebkitAppearance:'none' as const,cursor:'pointer'};
const label={display:'block',fontSize:12.5,fontWeight:600,color:MUTED,marginBottom:6};

export default function RegisterPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState<FormData>({ businessName:'', ownerName:'', email:'', phone:'', category:'', region:'', notification:'whatsapp' });
  const upd = (f: keyof FormData, v: string) => setForm((p) => ({ ...p, [f]: v }));
  const submit = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/register', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) });
      if (res.ok) router.push('/dashboard'); else { const d = await res.json(); alert(d.error || 'Error'); }
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };
  const btnP={flex:1,background:DARK,color:'#fff',fontWeight:700,padding:'12px',borderRadius:8,border:'none',cursor:'pointer',fontSize:15};
  const btnG={flex:1,background:'#fff',color:'#5b6b7a',fontWeight:600,padding:'12px',borderRadius:8,border:`1px solid ${BORDER}`,cursor:'pointer',fontSize:15};
  const sel=(f:keyof FormData,opts:string[])=>(
    <div style={{position:'relative'}}>
      <select value={form[f]} onChange={(e)=>upd(f,e.target.value)} style={selField}><option value="">בחרו…</option>{opts.map(o=><option key={o} value={o}>{o}</option>)}</select>
      <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)',fontSize:10,color:'#9aa6b2',pointerEvents:'none'}}>▾</span>
    </div>
  );

  return (
    <main style={{minHeight:'100vh',background:'#f6f8fa',display:'flex',alignItems:'center',justifyContent:'center',padding:16,direction:'rtl',fontFamily:"'Assistant','Rubik',Arial,sans-serif",color:DARK}}>
      <div style={{background:'#fff',borderRadius:14,boxShadow:'0 16px 40px rgba(26,35,48,.10)',border:`1px solid ${BORDER}`,padding:32,width:'100%',maxWidth:440}}>
        <div style={{display:'flex',alignItems:'center',gap:11,justifyContent:'center',marginBottom:24}}>
          <div style={{width:34,height:34,borderRadius:8,background:BLUE,display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:16,fontWeight:800}}>ש</div>
          <div style={{fontWeight:800,fontSize:20,color:DARK}}>שווה מכרזים</div>
        </div>
        <div style={{display:'flex',gap:6,marginBottom:26}}>{[1,2,3].map((n)=>(<div key={n} style={{flex:1,height:5,borderRadius:999,background:step>=n?BLUE:'#e2e7ec'}}/>))}</div>

        {step===1&&(
          <div style={{display:'flex',flexDirection:'column',gap:14}}>
            <h2 style={{fontSize:20,fontWeight:700,margin:'0 0 4px'}}>פרטי עסק</h2>
            <div><label style={label}>שם עסק</label><input type="text" value={form.businessName} onChange={(e)=>upd('businessName',e.target.value)} style={field}/></div>
            <div><label style={label}>שם בעלים</label><input type="text" value={form.ownerName} onChange={(e)=>upd('ownerName',e.target.value)} style={field}/></div>
            <div><label style={label}>אימייל</label><input type="email" value={form.email} onChange={(e)=>upd('email',e.target.value)} style={field}/></div>
            <div><label style={label}>טלפון</label><input type="tel" value={form.phone} onChange={(e)=>upd('phone',e.target.value)} style={field}/></div>
            <button onClick={()=>setStep(2)} disabled={!form.businessName||!form.email||!form.phone} style={{...btnP,background:(!form.businessName||!form.email||!form.phone)?'#c2ccd6':DARK,cursor:(!form.businessName||!form.email||!form.phone)?'default':'pointer'}}>המשך</button>
          </div>
        )}
        {step===2&&(
          <div style={{display:'flex',flexDirection:'column',gap:14}}>
            <h2 style={{fontSize:20,fontWeight:700,margin:'0 0 4px'}}>פרופיל עסקי</h2>
            <div><label style={label}>תחום עסק</label>{sel('category',cats)}</div>
            <div><label style={label}>אזור</label>{sel('region',regs)}</div>
            <div style={{display:'flex',gap:12}}>
              <button onClick={()=>setStep(1)} style={btnG}>חזרה</button>
              <button onClick={()=>setStep(3)} disabled={!form.category||!form.region} style={{...btnP,background:(!form.category||!form.region)?'#c2ccd6':DARK,cursor:(!form.category||!form.region)?'default':'pointer'}}>המשך</button>
            </div>
          </div>
        )}
        {step===3&&(
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            <h2 style={{fontSize:20,fontWeight:700,margin:'0 0 8px'}}>עדכונים</h2>
            {[{v:'whatsapp',l:'WhatsApp'},{v:'email',l:'אימייל'},{v:'both',l:'שניהם'}].map(({v,l})=>{
              const on=form.notification===v;
              return(
                <label key={v} style={{display:'flex',alignItems:'center',gap:12,padding:14,border:on?`1px solid ${BLUE}`:`1px solid ${BORDER}`,borderRadius:8,cursor:'pointer',background:on?'#e8f1fb':'#fff'}}>
                  <input type="radio" name="notification" value={v} checked={on} onChange={()=>upd('notification',v)} style={{accentColor:BLUE,width:17,height:17}}/>
                  <span style={{fontWeight:600,fontSize:15,color:'#33475b'}}>{l}</span>
                </label>
              );
            })}
            <div style={{display:'flex',gap:12,marginTop:12}}>
              <button onClick={()=>setStep(2)} style={btnG}>חזרה</button>
              <button onClick={submit} disabled={loading} style={{...btnP,background:loading?'#c2ccd6':'#1e7d45',cursor:loading?'default':'pointer'}}>{loading?'שומר…':'הרשמה'}</button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
