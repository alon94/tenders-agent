"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import AppShell from "../components/AppShell";

const DARK="#1a2330",BLUE="#2b6fc4",MUTED="#667380",BORDER="#e6eaee";

const BIZ=[
  {id:'consulting',label:'ייעוץ וניהול'},{id:'tech',label:'טכנולוגיה ותוכנה'},{id:'marketing',label:'שיווק ופרסום'},
  {id:'construction',label:'בינוי ותשתיות'},{id:'legal',label:'משפט וחשבונאות'},{id:'education',label:'חינוך והדרכה'},
  {id:'security',label:'אבטחה ושמירה'},{id:'cleaning',label:'ניקיון ותחזוקה'},{id:'catering',label:'קייטרינג ומזון'},
  {id:'transport',label:'הסעות ולוגיסטיקה'},{id:'health',label:'בריאות ורפואה'},{id:'environment',label:'איכות סביבה'},
];
const REGS=[{id:'all',label:'כל הארץ'},{id:'national',label:'ארצי / ממשלתי'},{id:'north',label:'צפון'},{id:'haifa',label:'חיפה'},{id:'center',label:'מרכז'},{id:'tlv',label:'תל אביב'},{id:'south',label:'דרום'},{id:'jerusalem',label:'ירושלים'}];
const PUBS=[{id:'all',label:'כל המפרסמים'},{id:'gov',label:'משרדי ממשלה'},{id:'local',label:'רשויות מקומיות'},{id:'health',label:'מערכת הבריאות'},{id:'edu',label:'מוסדות חינוך'},{id:'infra',label:'חברות ממשלתיות'}];

const selStyle={padding:'11px 34px 11px 14px',borderRadius:8,border:`1px solid #e2e7ec`,background:'#fff',color:'#33475b',fontSize:14,width:'100%',maxWidth:320,appearance:'none' as const,WebkitAppearance:'none' as const,fontFamily:'inherit',cursor:'pointer'};

function Card({title,desc,children}:{title:string;desc?:string;children:React.ReactNode}){
  return(
    <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,padding:'20px 22px',marginBottom:14}}>
      <h2 style={{margin:'0 0 4px',fontSize:16,fontWeight:700,color:DARK}}>{title}</h2>
      {desc&&<p style={{margin:'0 0 16px',fontSize:13,color:MUTED}}>{desc}</p>}
      {children}
    </div>
  );
}

export default function ProfilePage(){
  const router=useRouter();
  const[biz,setBiz]=useState('');
  const[reg,setReg]=useState('all');
  const[pub,setPub]=useState('all');
  const[saved,setSaved]=useState(false);
  const save=()=>{localStorage.setItem('businessProfile',JSON.stringify({businessType:biz,region:reg,publisherType:pub}));setSaved(true);setTimeout(()=>router.push('/dashboard'),1000);};

  return(
    <AppShell active="/profile" title="פרופיל עסקי">
      <div style={{fontSize:13,color:MUTED,marginBottom:18}}>הפרופיל קובע אילו מכרזים יותאמו ויוצגו לכם</div>

      <Card title="🎯 סוג העסק שלי" desc="בחרו קטגוריה — היא תקבע אילו מכרזים יוצגו לכם">
        <div style={{display:'flex',flexWrap:'wrap',gap:9}}>
          {BIZ.map(bt=>{const on=biz===bt.id;return(
            <button key={bt.id} onClick={()=>setBiz(on?'':bt.id)} style={{padding:'9px 16px',borderRadius:8,border:on?`1px solid ${BLUE}`:'1px solid #e2e7ec',background:on?'#e8f1fb':'#fff',color:on?'#1e5aa8':'#5b6b7a',cursor:'pointer',fontSize:14,fontWeight:on?700:500}}>{bt.label}</button>
          );})}
        </div>
        {!biz?<p style={{margin:'14px 0 0',color:'#96731a',fontSize:13}}>⚠️ לא נבחר סוג עסק — יוצגו כל המכרזים</p>
             :<p style={{margin:'14px 0 0',color:'#1e7d45',fontSize:13,fontWeight:600}}>✅ נבחר: {BIZ.find(b=>b.id===biz)?.label}</p>}
      </Card>

      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))',gap:14}}>
        <Card title="🗺️ אזור גאוגרפי" desc="פילטר משני">
          <div style={{position:'relative',maxWidth:320}}>
            <select value={reg} onChange={e=>setReg(e.target.value)} style={selStyle}>{REGS.map(r=><option key={r.id} value={r.id}>{r.label}</option>)}</select>
            <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)',fontSize:10,color:'#9aa6b2',pointerEvents:'none'}}>▾</span>
          </div>
        </Card>
        <Card title="🏛️ סוג מפרסם" desc="פילטר משני">
          <div style={{position:'relative',maxWidth:320}}>
            <select value={pub} onChange={e=>setPub(e.target.value)} style={selStyle}>{PUBS.map(p=><option key={p.id} value={p.id}>{p.label}</option>)}</select>
            <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)',fontSize:10,color:'#9aa6b2',pointerEvents:'none'}}>▾</span>
          </div>
        </Card>
      </div>

      <button onClick={save} style={{marginTop:8,padding:'13px 28px',borderRadius:8,border:'none',background:saved?'#1e7d45':DARK,color:'#fff',fontSize:15,fontWeight:700,cursor:'pointer'}}>
        {saved?'✅ נשמר! מעביר לדשבורד…':'💾 שמירת פרופיל ומעבר לדשבורד'}
      </button>
    </AppShell>
  );
}
