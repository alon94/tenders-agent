"use client";
import AppShell from "../components/AppShell";

const DARK="#1a2330",BLUE="#2b6fc4",MUTED="#667380",BORDER="#e6eaee";

export default function GuaranteePage(){
  const services=[
    {icon:'🛡',title:'ערבויות מכרז וביצוע',desc:'הנפקת ערבויות בנקאיות ומוסדיות במהירות, בהתאמה לדרישות המכרז — ללא בירוקרטיה מיותרת.'},
    {icon:'📋',title:'ליווי בהגשת ההצעה',desc:'בדיקת עמידה בתנאי הסף, ארגון המסמכים והגשה מסודרת במועד — כדי שלא תיפסלו על טכניקה.'},
    {icon:'⚖️',title:'ייעוץ משפטי ומקצועי',desc:'חוות דעת על תנאי המכרז, ליווי בשאלות הבהרה ובהשגות מול הגוף המפרסם.'},
    {icon:'💰',title:'מימון וגישור פיננסי',desc:'פתרונות מימון להון חוזר ולעמידה בדרישות איתנות פיננסית של מכרזים גדולים.'},
  ];
  return(
    <AppShell active="/guarantee" title="ערבויות וליווי">
      <div style={{background:DARK,borderRadius:12,padding:'26px 28px',color:'#fff',marginBottom:18,display:'flex',alignItems:'center',gap:20,flexWrap:'wrap'}}>
        <div style={{flex:1,minWidth:260}}>
          <div style={{fontSize:22,fontWeight:700,marginBottom:8}}>🛡 מרגע שמצאתם מכרז — אנחנו איתכם עד ההגשה</div>
          <div style={{fontSize:14,opacity:.85,lineHeight:1.6,maxWidth:560}}>ערבויות, ליווי מקצועי ומימון, הכול תחת קורת גג אחת.</div>
        </div>
        <a href="/register" style={{background:BLUE,color:'#fff',fontWeight:600,fontSize:14,padding:'11px 22px',borderRadius:8,textDecoration:'none',flex:'0 0 auto'}}>יצירת קשר</a>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))',gap:14}}>
        {services.map((s,i)=>(
          <div key={i} style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,padding:'22px 24px'}}>
            <div style={{fontSize:26,marginBottom:12}}>{s.icon}</div>
            <div style={{fontSize:17,fontWeight:700,color:DARK,marginBottom:8}}>{s.title}</div>
            <div style={{fontSize:13.5,color:'#5b6b7a',lineHeight:1.6}}>{s.desc}</div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
