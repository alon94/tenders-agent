# DIFF מדויק — גרסת מובייל ל-`tenders-agent`

> before/after מול הקוד הקיים ב-`main`. כל שינוי הוא **הוספה** או **החלפה נקודתית** — הדסקטופ לא נשבר (כל שינוי מותנה ב-`isMobile`).
> סדר עבודה: 2 קבצים חדשים (§1, §2), ואז 6 עריכות נקודתיות ב-`app/dashboard/page.tsx` (§3).

---

## §1 — קובץ חדש: `app/hooks/useIsMobile.ts`
```ts
'use client';
import { useEffect, useState } from 'react';

export function useIsMobile(bp = 768) {
  const [m, setM] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia(`(max-width:${bp}px)`);
    const on = () => setM(mq.matches);
    on();
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, [bp]);
  return m;
}
```

## §2 — קובץ חדש: `app/components/MobileTabBar.tsx`
```tsx
'use client';
import { usePathname } from 'next/navigation';

const TABS = [
  { icon: '◧', label: 'גילוי', href: '/dashboard' },
  { icon: '★', label: 'מסומנים', href: '/marked' },
  { icon: '◈', label: 'סוכן', href: '/agent' },
  { icon: '▤', label: 'ערבויות', href: '/guarantee' },
  { icon: '⛁', label: 'מקורות', href: '/sources' },
];
const BLUE = '#2b6fc4', MUTED = '#8a97a3', BORDER = '#e6eaee';

export default function MobileTabBar() {
  const path = usePathname();
  return (
    <nav style={{
      position: 'fixed', insetInline: 0, bottom: 0, zIndex: 200,
      background: '#fff', borderTop: `1px solid ${BORDER}`,
      padding: '8px 8px calc(8px + env(safe-area-inset-bottom))',
      display: 'flex', justifyContent: 'space-around', direction: 'rtl',
    }}>
      {TABS.map(t => {
        const active = path === t.href || (path?.startsWith(t.href + '/') ?? false);
        return (
          <a key={t.href} href={t.href} style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            textDecoration: 'none', minWidth: 56,
            color: active ? BLUE : MUTED, fontWeight: active ? 700 : 500,
          }}>
            <span style={{ fontSize: 19 }}>{t.icon}</span>
            <span style={{ fontSize: 10 }}>{t.label}</span>
          </a>
        );
      })}
    </nav>
  );
}
```

---

## §3 — עריכות ב-`app/dashboard/page.tsx`

### 3.1 — Imports (ראש הקובץ)
**BEFORE**
```tsx
"use client";
import { useState, useEffect, useMemo, useCallback } from "react";
```
**AFTER**
```tsx
"use client";
import { useState, useEffect, useMemo, useCallback } from "react";
import { useIsMobile } from "../hooks/useIsMobile";
import MobileTabBar from "../components/MobileTabBar";
```

### 3.2 — הגדרת isMobile (בתחילת הקומפוננטה)
**BEFORE**
```tsx
export default function Dashboard(){
  const[all,setAll]=useState<T[]>([]);
```
**AFTER**
```tsx
export default function Dashboard(){
  const isMobile=useIsMobile();
  const[all,setAll]=useState<T[]>([]);
```

### 3.3 — הסתרת הסרגל במובייל
**BEFORE**
```tsx
        {/* ===== SIDEBAR ===== */}
        <div style={{flex:'0 0 238px',background:'#fff',borderInlineEnd:`1px solid ${BORDER}`,padding:'22px 16px',display:'flex',flexDirection:'column',gap:3,position:'sticky',top:0,alignSelf:'flex-start',height:'100vh'}}>
```
**AFTER**
```tsx
        {/* ===== SIDEBAR ===== */}
        <div style={{flex:'0 0 238px',background:'#fff',borderInlineEnd:`1px solid ${BORDER}`,padding:'22px 16px',display:isMobile?'none':'flex',flexDirection:'column',gap:3,position:'sticky',top:0,alignSelf:'flex-start',height:'100vh'}}>
```
> שינוי יחיד: `display:'flex'` → `display:isMobile?'none':'flex'`.

### 3.4 — Header רספונסיבי
**BEFORE**
```tsx
          {/* header */}
          <div style={{background:'#fff',borderBottom:`1px solid ${BORDER}`,padding:'15px 26px',display:'flex',alignItems:'center',gap:18,position:'sticky',top:0,zIndex:5}}>
            <div style={{fontWeight:700,fontSize:20,color:DARK,flex:'0 0 auto'}}>גילוי מכרזים</div>
            <div style={{flex:1,display:'flex',alignItems:'center',gap:9,background:'#f4f6f8',border:'1px solid #e2e7ec',borderRadius:8,padding:'9px 14px',maxWidth:440}}>
              <span style={{color:'#9aa6b2',fontSize:15}}>⌕</span>
              <input value={q} onChange={e=>{setQ(e.target.value);setPg(1);}} placeholder="חיפוש: נושא, גוף מפרסם, מספר מכרז…" style={{flex:1,border:'none',outline:'none',background:'transparent',fontSize:13.5,color:DARK,fontFamily:'inherit'}}/>
            </div>
            <span style={{marginInlineStart:'auto',fontSize:12.5,color:'#7a8794',display:'inline-flex',alignItems:'center',gap:7,flex:'0 0 auto'}}>
              <span style={{width:7,height:7,borderRadius:999,background:BLUE}}></span>
              {loading?'טוען…':`עודכן ${new Date().toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})} · `}
              <a href="https://data.gov.il" target="_blank" rel="noopener noreferrer" style={{color:'#7a8794'}}>data.gov.il</a>
            </span>
            <a href="/agent" style={{background:BLUE,color:'#fff',fontWeight:600,fontSize:13,padding:'9px 16px',borderRadius:8,textDecoration:'none',flex:'0 0 auto'}}>✦ תובנות AI</a>
            <a href="/profile" style={{width:32,height:32,borderRadius:8,background:'#eef1f4',color:DARK,display:'inline-flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:13,textDecoration:'none',flex:'0 0 auto'}}>א</a>
          </div>
```
**AFTER**
```tsx
          {/* header */}
          <div style={{background:'#fff',borderBottom:`1px solid ${BORDER}`,padding:isMobile?'12px 16px':'15px 26px',display:'flex',alignItems:'center',gap:isMobile?10:18,flexWrap:isMobile?'wrap':'nowrap',position:'sticky',top:0,zIndex:5}}>
            <div style={{fontWeight:700,fontSize:isMobile?18:20,color:DARK,flex:'0 0 auto'}}>גילוי מכרזים</div>
            {!isMobile&&(
              <span style={{marginInlineStart:'auto',fontSize:12.5,color:'#7a8794',display:'inline-flex',alignItems:'center',gap:7,flex:'0 0 auto',order:2}}>
                <span style={{width:7,height:7,borderRadius:999,background:BLUE}}></span>
                {loading?'טוען…':`עודכן ${new Date().toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})} · `}
                <a href="https://data.gov.il" target="_blank" rel="noopener noreferrer" style={{color:'#7a8794'}}>data.gov.il</a>
              </span>
            )}
            {isMobile&&(
              <a href="/profile" style={{marginInlineStart:'auto',width:36,height:36,borderRadius:999,background:'#eef1f4',color:DARK,display:'inline-flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:14,textDecoration:'none',flex:'0 0 auto'}}>א</a>
            )}
            <div style={{flex:isMobile?'1 1 100%':1,display:'flex',alignItems:'center',gap:9,background:'#f4f6f8',border:'1px solid #e2e7ec',borderRadius:isMobile?12:8,padding:isMobile?'11px 14px':'9px 14px',maxWidth:isMobile?'none':440,order:isMobile?3:0}}>
              <span style={{color:'#9aa6b2',fontSize:15}}>⌕</span>
              <input value={q} onChange={e=>{setQ(e.target.value);setPg(1);}} placeholder="חיפוש: נושא, גוף מפרסם…" style={{flex:1,border:'none',outline:'none',background:'transparent',fontSize:13.5,color:DARK,fontFamily:'inherit'}}/>
            </div>
            {!isMobile&&<a href="/agent" style={{background:BLUE,color:'#fff',fontWeight:600,fontSize:13,padding:'9px 16px',borderRadius:8,textDecoration:'none',flex:'0 0 auto'}}>✦ תובנות AI</a>}
            {!isMobile&&<a href="/profile" style={{width:32,height:32,borderRadius:8,background:'#eef1f4',color:DARK,display:'inline-flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:13,textDecoration:'none',flex:'0 0 auto'}}>א</a>}
          </div>
```

### 3.5 — עטיפת התוכן: padding-bottom לניווט התחתון
**BEFORE**
```tsx
          <div style={{padding:'22px 26px 30px'}}>
            {/* KPI strip */}
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:1,background:BORDER,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden',marginBottom:22}}>
              {kpis.map(k=>(
                <div key={k.label} style={{background:'#fff',padding:'16px 18px'}}>
```
**AFTER**
```tsx
          <div style={{padding:isMobile?'16px 16px 88px':'22px 26px 30px'}}>
            {/* KPI strip */}
            <div style={isMobile
              ? {display:'flex',gap:10,overflowX:'auto',marginBottom:18,paddingBottom:2}
              : {display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:1,background:BORDER,border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden',marginBottom:22}}>
              {kpis.map(k=>(
                <div key={k.label} style={isMobile
                  ? {flex:'0 0 auto',minWidth:130,background:'#fff',border:`1px solid ${BORDER}`,borderRadius:12,padding:'14px 16px'}
                  : {background:'#fff',padding:'16px 18px'}}>
```
> שאר תוכן ה-KPI (הנקודה, המספר, התווית) נשאר בדיוק כפי שהוא.

### 3.6 — הסתרת שורת כותרת הטבלה במובייל
**BEFORE**
```tsx
            {/* table */}
            <div style={{background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
              <div style={{display:'grid',gridTemplateColumns:'70px 1fr 232px 156px 96px',padding:'12px 18px',background:'#f7f9fb',borderBottom:`1px solid ${BORDER}`,fontSize:12,fontWeight:700,color:'#8a97a3'}}>
                <span>ציון</span><span>נושא המכרז</span><span>סטטוס</span><span>מועד הגשה</span><span></span>
              </div>
```
**AFTER**
```tsx
            {/* table */}
            <div style={isMobile
              ? {display:'flex',flexDirection:'column',gap:12,background:'transparent'}
              : {background:'#fff',border:`1px solid ${BORDER}`,borderRadius:10,overflow:'hidden'}}>
              {!isMobile&&(
              <div style={{display:'grid',gridTemplateColumns:'70px 1fr 232px 156px 96px',padding:'12px 18px',background:'#f7f9fb',borderBottom:`1px solid ${BORDER}`,fontSize:12,fontWeight:700,color:'#8a97a3'}}>
                <span>ציון</span><span>נושא המכרז</span><span>סטטוס</span><span>מועד הגשה</span><span></span>
              </div>
              )}
```
> ה-`</div>` הסוגר של מכולת הטבלה נשאר כפי שהוא — לא לגעת.

### 3.7 — שורת מכרז: רינדור מותנה (כרטיס במובייל)
**BEFORE**
```tsx
                const isMarked=marked.includes(t.id);
                return(
                  <div key={t.id||i} style={{display:'grid',gridTemplateColumns:'70px 1fr 232px 156px 96px',padding:'16px 18px',borderBottom:'1px solid #eef1f4',alignItems:'center'}}>
```
**AFTER** — הוסף את בלוק המובייל **לפני** ה-`return(` הקיים, והפוך אותו ל-`return isMobile ? (...) : (`:
```tsx
                const isMarked=marked.includes(t.id);
                return isMobile ? (
                  <a key={t.id||i} href={t.id?`/tender/${t.id}`:undefined} style={{display:'block',textDecoration:'none',background:'#fff',border:`1px solid ${BORDER}`,borderRadius:16,padding:'15px 16px'}}>
                    <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',gap:10,marginBottom:11}}>
                      <div style={{display:'flex',flexWrap:'wrap',gap:6,flex:1}}>
                        {tags.map((g,gi)=>(<span key={gi} style={{fontSize:11,fontWeight:600,padding:'3px 9px',borderRadius:6,background:g.bg,color:g.fg,border:`1px solid ${g.bd}`}}>{g.label}</span>))}
                      </div>
                      <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4,flex:'0 0 auto'}}>
                        <span style={{fontSize:22,fontWeight:700,color:DARK,lineHeight:1}}>{score}</span>
                        <span style={{width:26,height:3,borderRadius:2,background:bandColor(score)}}></span>
                      </div>
                    </div>
                    <div style={{fontSize:15,fontWeight:700,color:DARK,lineHeight:1.45,textAlign:'right'}}>{t.title||'ללא כותרת'}</div>
                    <div style={{fontSize:12,color:'#7a8794',marginTop:8}}>{t.publisher||'לא ידוע'} · פורסם {fd(t.publishDate)}</div>
                    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:13,paddingTop:12,borderTop:'1px solid #eef1f4'}}>
                      <div style={{fontSize:12.5}}>
                        <span style={{color:'#7a8794'}}>הגשה עד </span>
                        <span style={{color:DARK,fontWeight:700}}>{fd(t.deadline)}</span>
                        {d!==null&&d>=0&&<span style={{color:d<=7?'#b04a34':'#7a8794'}}> · נותרו {d} ימים</span>}
                      </div>
                      <button onClick={(e)=>toggleMark(t.id,e)} title={isMarked?'הסר סימון':'סמן מכרז'} style={{fontSize:18,color:isMarked?'#d9a520':'#c2ccd6',background:'transparent',border:'none',cursor:'pointer',padding:6}}>{isMarked?'★':'☆'}</button>
                    </div>
                  </a>
                ) : (
                  <div key={t.id||i} style={{display:'grid',gridTemplateColumns:'70px 1fr 232px 156px 96px',padding:'16px 18px',borderBottom:'1px solid #eef1f4',alignItems:'center'}}>
```
> כל הבלוק הפנימי הקיים של השורה בדסקטופ (הציון, הכותרת, התגיות, המועד, כפתור הסימון) נשאר **ללא שינוי**. רק ודא שבסוף השורה, ה-`</div>` הסוגר וה-`);` נשארים — כעת ה-`)` סוגר את הטרנרי.

### 3.8 — רינדור הניווט התחתון (סוף ה-return)
**BEFORE** (שתי השורות הסוגרות האחרונות של ה-JSX)
```tsx
        </div>
      </div>
    </div>
  );
}
```
**AFTER**
```tsx
        </div>
      </div>
      {isMobile&&<MobileTabBar/>}
    </div>
  );
}
```
> `<MobileTabBar/>` ממוקם אחרי מכולת ה-flex ולפני ה-`</div>` החיצוני ביותר. `position:fixed` שלו דואג למיקום.

---

## בדיקה
1. `npm run dev` → פתח `/dashboard`, DevTools → iPhone (390px).
2. ודא: **הכותרות זורמות** (לא אות-אות), אין horizontal scroll, KPI נגלל אופקית, ניווט תחתון קבוע ולא מסתיר תוכן (בזכות `padding-bottom:88`).
3. הרחב חזרה ל-≥769px → הדסקטופ **זהה** למקור.

## הדפים הפנימיים (מומלץ להוסיף אחרי הדשבורד)
בכל אחד מ-`marked`/`agent`/`guarantee`/`tender/[id]`: הוסף `const isMobile=useIsMobile();`, `paddingBottom:isMobile?88:…` למכולת התוכן, ו-`{isMobile&&<MobileTabBar/>}` לפני הסגירה. `tender/[id]` כבר מכיל `@media(max-width:700px)` ב-`globals.css` — רק ודא שהפעולות הופכות לבר תחתון ברוחב מלא.
